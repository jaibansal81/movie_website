import fresh_tomatoes

import media

# Movie function is called from medias file where movies description are passed

Inception = media.Movie("Inception",
                        "Dom Cobb (Leonardo DiCaprio) is a thief with the rare ability to \
                        enter people's dreams and steal their secrets\
                        from their subconscious",
                        "https://upload.wikimedia.org/wikipedia/en/2/2e/Inception_%282010%29_theatrical_poster.jpg",  # NOQA
                        "https://www.youtube.com/watch?v=8hP9D6kZseM")

Avatar = media.Movie("Avatar",
                     "A marine on an alien planet",
                     "https://upload.wikimedia.org/wikipedia/en/b/b0/Avatar-Teaser-Poster.jpg",  # NOQA
                     "https://www.youtube.com/watch?v=5PSNL1qE6VY")

Avengers_Infinty_war = media.Movie("Avengers:Infinty war",
                                   "The Avengers and their allies must be willing to sacrifice all in an\
                                   attempt to defeat the powerful\
                                   Thanos before his blitz of devastation ",
                                   "https://m.media-amazon.com/images/M/MV5BMjMxNjY2MDU1OV5BMl5BanBnXkFtZTgwNzY1MTUwNTM@._V1_QL50_SY1000_CR0,0,674,1000_AL_.jpg",  # NOQA
                                   "https://www.youtube.com/\
                                   watch?v=6ZfuNTqbHE8")

Deadpool = media.Movie("Deadpool",
                       "A fast-talking mercenary with a morbid sense of\
                       humor is subjected to a rogue\
                       experiment that leaves him with accelerated \
                       healing powers and a quest for revenge.",
                       "https://m.media-amazon.com/images/M/MV5BYzE5MjY1ZDgtMTkyNC00MTMyLThhMjAtZGI5OTE1NzFlZGJjXkEyXkFqcGdeQXVyNjU0OTQ0OTY@._V1_QL50_SY1000_CR0,0,666,1000_AL_.jpg",  # NOQA
                       "https://www.youtube.com/watch?v=ONHBaC-pfsk")

The_Godfather = media.Movie("The Godfather",
                            "The aging patriarch of an organized crime dynasty transfers \
                            control of his clandestine empire \
                            to his reluctant son",
                            "https://m.media-amazon.com/images/M/MV5BM2MyNjYxNmUtYTAwNi00MTYxLWJmNWYtYzZlODY3ZTk3OTFlXkEyXkFqcGdeQXVyNzkwMjQ5NzM@._V1_QL50_SY1000_CR0,0,704,1000_AL_.jpg",  # NOQA
                            "https://www.youtube.com/watch?v=sY1S34973zA")

Logan = media.Movie("Logan",
                    "In the near future, a weary Logan cares for an ailing Professor X,\
                    somewhere on the Mexican border.",
                    "https://m.media-amazon.com/images/M/MV5BYzc5MTU4N2EtYTkyMi00NjdhLTg3NWEtMTY4OTEyMzJhZTAzXkEyXkFqcGdeQXVyNjc1NTYyMjg@._V1_QL50_.jpg",  # NOQA
                    "https://www.youtube.com/watch?v=Div0iP65aZo")

# movies is the array of different movies

# open_movies_page function will open a webpage that shows the all movies

movies = [Inception, Avatar, Avengers_Infinty_war,

          Deadpool, The_Godfather, Logan]

fresh_tomatoes.open_movies_page(movies)
